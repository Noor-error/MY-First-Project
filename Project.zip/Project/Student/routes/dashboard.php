<?php
session_start();
if (!isset($_SESSION['userdata'])) {
    header("location: ../");
}
$userdata = $_SESSION['userdata'];
$groupsdata = $_SESSION['groupsdata'];

$status = $_SESSION['userdata']['status'] == 0 ? '<b style="color:red">Not Voted</b>' : '<b style="color:green">Voted</b>';
?>


<html>
<head>
    <title>Vote4Teachers</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        #mainSection {
            width: 80%;
            margin: auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
        }

        #headerSection {
            background-color: #4a90e2;
            padding: 20px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        #headerSection h1 {
            margin: 0;
            font-size: 24px;
        }

        #backbtn, #logoutbtn, #votebtn, #voted {
            padding: 10px;
            border-radius: 10px;
            width: 120px;
            background-color: red;
            font-size: 16px;
            color: white;
            margin: 10px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        #backbtn:hover, #logoutbtn:hover, #votebtn:hover {
            background-color: #C0392B;
        }

        #logoutbtn {
            background-color: red;
        }

        #logoutbtn:hover {
            background-color: #C0392B;
        }

        #mainpanel {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 20px;
            padding: 20px;
            justify-content:center;
        }

        #Profile {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            position: center;
            display:flex;
            flex-direction: column;
            align-items:center;
        }

        #Profile:before {
            content: "Student's Profile";
            width: 200px;
            font-size: 15px;
            color: #4a90e2;
            background-color: #fff;
            padding: 5px;
            border-radius: 5px;
            border: 1px solid #4a90e2;
            margin-bottom: 10px;
            display: block;
            position: relative;
            top: -15px;
            left: 20px;
        }

        #Profile img {
            border-radius: 50%;
            margin-right: 20px;
            margin-bottom: 10px;
            border: 2px solid #4a90e2;
        }

        #Profile div {
            flex: 1;
        }

        #Group {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        #Group:before {
            content: "Teachers Available";
            font-size: 14px;
            color: #4a90e2;
        
            background-color: #fff;
            padding: 5px;
            border-radius: 5px;
            border: 1px solid #4a90e2;
            margin-bottom: 10px;
            display: block;
        }

        #Group > div {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }

        #Group img {
            border-radius: 50%;
            margin-right: 20px;
            border: 2px solid #4a90e2;
        }

        #Group div > div {
            display: block;
            flex: 1;
        }

        #Group form {
            margin-left: auto;
        }

        #voted {
            background-color: green;
            border: none;
            cursor: not-allowed;
        }

        hr {
            border: 0;
            height: 1px;
            background: #e0e0e0;
            margin: 0;
        }
    </style>
</head>
<body>
    <div id="mainSection">
        <div id="headerSection">
            <a href="../"><button id="backbtn">Back</button></a>
            <h1>Vote4Teachers</h1>
            <a href="logout.php"><button id="logoutbtn">Log Out</button></a>
        </div>
        <hr>
        <div id="mainpanel">
            <div id="Profile">
                <img src="../uploads/<?php echo $userdata['photo']; ?>" height="100" width="100">
                <div>
                    <p><b>Student Name:</b> <?php echo $userdata['name']; ?></p>
                    <p><b>Mobile:</b> <?php echo $userdata['mobile']; ?></p>
                    <p><b>Student Id:</b> <?php echo $userdata['address']; ?></p>
                    <p><b>Status:</b> <?php echo $status; ?></p>
                </div>
            </div>
           <div id="Group">
                <?php
                if ($_SESSION['groupsdata']) {
                    for ($i = 0; $i < count($groupsdata); $i++) {
                ?>
                        <div>
                            <img src="../uploads/<?php echo $groupsdata[$i]['photo']; ?>" height="100" width="100">
                            <div>
                                <p><b>Teacher Name:</b> <?php echo $groupsdata[$i]['name']; ?></p>
                                
                            <p><b>Subject:</b> <?php echo $groupsdata[$i]['address']; ?></p>
                                <p><b>Votes:</b> <?php echo $groupsdata[$i]['votes']; ?></p>
                            </div>
                            <form action="../api/vote.php" method="post">
                                <input type="hidden" name="gvotes" value="<?php echo $groupsdata[$i]['votes']; ?>">
                                <input type="hidden" name="gid" value="<?php echo $groupsdata[$i]['id']; ?>">
                                <?php if ($_SESSION['userdata']['status'] == 0) { ?>
                                    <input type="submit" name="votebtn" value="Vote" id="votebtn">
                                <?php } else { ?>
                                    <button disabled type="button" id="voted">Voted</button>
                                <?php } ?>
                            </form>
                        </div>
                <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>