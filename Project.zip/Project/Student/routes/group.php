<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include("../api/connect.php");

// Check if user is logged in and is a group
if (!isset($_SESSION['userdata']) || $_SESSION['userdata']['role'] != 2) {
    header('Location: ../index.html'); // Redirect to login if not authorized
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Group Dashboard</title>
</head>
<body>
    <div class="container">
        <h1>Welcome to the Group Dashboard!</h1>
        <p>Hello, <?php echo $_SESSION['userdata']['name']; ?>. You have successfully logged in as a group.</p>
    </div>
</body>
</html>