<?php
include '../../TeacherJob/connect.php'; // Connect to the teacher_jobs database

// Fetch available schools from the database for the dropdown
$schools_sql = "SELECT id, name FROM schools";
$schools_result = $conn->query($schools_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Job</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e9ecef;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            font-size: 28px;
        }
        label {
            font-weight: bold;
            color: #555;
            display: block;
            margin-bottom: 8px;
        }
        input, select, textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            color: #555;
            transition: border-color 0.3s;
        }
        input:focus, select:focus, textarea:focus {
            border-color: #3498db;
            outline: none;
        }
        button {
            width: 100%;
            padding: 14px;
            background-color: #3498db;
            border: none;
            color: white;
            font-size: 18px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #2980b9;
        }
        @media (max-width: 600px) {
            .container {
                width: 90%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Add New Job</h2>
    <form action="submit_job.php" method="POST">
        <label for="job_title">Job Title:</label>
        <input type="text" id="job_title" name="job_title" placeholder="Enter job title" required>

        <label for="closing_date">Closing Date:</label>
        <input type="date" id="closing_date" name="closing_date" required>

        <label for="school_name">School Name:</label>
        <select id="school_name" name="school_id" required>
            <option value="" disabled selected>Select School</option>
            <?php
            if ($schools_result->num_rows > 0) {
                while($row = $schools_result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                }
            }
            ?>
        </select>

        <label for="job_description">Job Description:</label>
        <textarea id="job_description" name="job_description" placeholder="Enter job details" rows="5" required></textarea>

        <label for="qualifications">Qualifications:</label>
        <input type="text" id="qualifications" name="qualifications" placeholder="Enter qualifications" required>

        <button type="submit">Add Job</button>
    </form>
</div>

</body>
</html>