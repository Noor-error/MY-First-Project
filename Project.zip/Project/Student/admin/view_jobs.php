<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include '../../TeacherJob/connect.php'; // Connect to the teacher_jobs database

// Fetch all jobs
$jobs_sql = "SELECT * FROM jobs";
$jobs_result = $conn->query($jobs_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Jobs</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f0f4f8;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            font-size: 28px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 16px;
            text-align: left;
            font-size: 16px;
        }

        th {
            background-color: #0096FF;
            color: white;
        }

        td {
            border-bottom: 1px solid #ddd;
            background-color: #fff;
        }

        tr:hover td {
            background-color: #f1f1f1;
        }

        .action-btns {
            display: flex;
            gap: 10px;
        }

        .edit-btn, .delete-btn {
            padding: 8px 16px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .edit-btn {
            background-color: #28a745;
        }

        .delete-btn {
            background-color: #dc3545;
        }

        .edit-btn:hover {
            background-color: #218838;
            transform: scale(1.05);
        }

        .delete-btn:hover {
            background-color: #c82333;
            transform: scale(1.05);
        }

        @media (max-width: 768px) {
            table {
                font-size: 14px;
            }

            th, td {
                padding: 12px;
            }

            .action-btns {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>
<body>

    <h2>View Jobs</h2>

    <table>
        <tr>
            <th>Job Title</th>
            <th>Description</th>
            <th>Closing Date</th>
            <th>Actions</th>
        </tr>

        <?php
        if ($jobs_result->num_rows > 0) {
            while($row = $jobs_result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['job_title'] . "</td>";
                echo "<td>" . $row['description'] . "</td>";
                echo "<td>" . $row['closing_date'] . "</td>";
                echo "<td class='action-btns'>
                        <a href='edit_job.php?id=" . $row['id'] . "' class='edit-btn'>Edit</a>
                        <a href='delete_job.php?id=" . $row['id'] . "' class='delete-btn'>Delete</a>
                      </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No jobs found</td></tr>";
        }
        ?>

    </table>

</body>
</html>