<?php
// Database connection for teacher_jobs
$servername = "127.0.0.1";
$username = "root";
$password = "";
$teacher_jobs_db = "teacher_jobs";

// Create connection
$teacher_conn = new mysqli($servername, $username, $password, $teacher_jobs_db);

// Check connection
if ($teacher_conn->connect_error) {
    die("Connection failed: " . $teacher_conn->connect_error);
}
