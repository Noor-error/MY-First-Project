<?php
include '../../TeacherJob/connect.php'; // Adjust path if needed

// Capture job data from the form
$job_title = $_POST['job_title'];
$description = $_POST['job_description'];
$school_id = intval($_POST['school_id']);
$closing_date = $_POST['closing_date']; // Capture the date from the form
$qualifications = $_POST['qualifications']; // Capture the qualifications

// Validate the date format
if (!DateTime::createFromFormat('Y-m-d', $closing_date)) {
    die("Invalid date format. Please enter the date in YYYY-MM-DD format.");
}

// Prepare the SQL statement with the qualifications field
$sql = "INSERT INTO jobs (job_title, description, school_id, closing_date, qualifications) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

// Check if the statement was prepared successfully
if ($stmt === false) {
    die("Error preparing the statement: " . $conn->error);
}

// Bind the parameters, including qualifications
$stmt->bind_param("ssiss", $job_title, $description, $school_id, $closing_date, $qualifications);

// Execute the query

if ($stmt->execute()) {
    $title = "Job added successfully";
echo "<h1>" . $title. "</h1>";
} else {
    die("Error adding job: " . $stmt->error);
}

// Close the statement and connection
$stmt->close();
$conn->close();
