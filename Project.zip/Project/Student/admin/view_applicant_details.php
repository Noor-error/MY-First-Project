<?php
include 'teacher_jobs_connect.php';  // Connect to the teacher_jobs database

// Get the applicant ID from the URL
$applicant_id = $_GET['id'];

// Fetch the details of the selected applicant
$sql = "SELECT a.id, a.name, a.email, a.phone, a.resume, j.job_title, s.name as school_name 
        FROM applications a 
        JOIN jobs j ON a.job_id = j.id 
        JOIN schools s ON j.school_id = s.id 
        WHERE a.id = $applicant_id";
$result = $teacher_conn->query($sql);

if ($result->num_rows > 0) {
    $applicant = $result->fetch_assoc();
} else {
    echo "No details found for this applicant.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applicant Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        header {
            background-color: #007BFF;
            width: 100%;
            padding: 20px;
            color: white;
            text-align: center;
            margin-bottom: 20px;
        }

        section {
            background-color: white;
            width: 60%;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        p {
            font-size: 16px;
            margin: 15px 0;
        }

        strong {
            color: #007BFF;
        }

        a {
            color: #007BFF;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        footer {
            margin-top: 20px;
        }

        footer a {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        footer a:hover {
            background-color: #0056b3;
        }

        @media screen and (max-width: 768px) {
            section {
                width: 90%;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Applicant Details</h1>
    </header>

    <section>
        <p><strong>ID:</strong> <?php echo $applicant['id']; ?></p>
        <p><strong>Name:</strong> <?php echo $applicant['name']; ?></p>
        <p><strong>Email:</strong> <?php echo $applicant['email']; ?></p>
        <p><strong>Phone:</strong> <?php echo $applicant['phone']; ?></p>
        <p><strong>Job Title:</strong> <?php echo $applicant['job_title']; ?></p>
        <p><strong>School Name:</strong> <?php echo $applicant['school_name']; ?></p>
        <p><strong>Resume:</strong> <a href="../../TeacherJob/resumes/<?php echo $applicant['resume']; ?>" target="_blank">View Resume</a></p>
    </section>

    <footer>
        <a href="view_applicants.php">Back to Applicants</a>
    </footer>
</body>
</html>

<?php
$teacher_conn->close();
?>



