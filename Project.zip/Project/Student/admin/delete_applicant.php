<?php
include 'teacher_jobs_connect.php'; // Ensure database connection

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare the delete query
    $sql = "DELETE FROM applicants WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "Applicant deleted successfully.";
    } else {
        echo "Error deleting applicant: " . $conn->error;
    }

    // Redirect back to view_applicants.php
    header("Location: view_applicants.php");
} else {
    echo "Invalid request.";
}

$conn->close();
?>
