<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

// Optional: Implement session timeout for additional security
if (isset($_SESSION['last_login_time'])) {
    if (time() - $_SESSION['last_login_time'] > 1800) { // 30 minutes
        session_unset();
        session_destroy();
        header("Location: admin_login.php");
        exit();
    } else {
        $_SESSION['last_login_time'] = time(); // Update last login time
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body{
            font-family: 'Arial', sans-serif;
            background-color: #f0f8ff;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }

        header {
            background-color: #0096FF;
            color: white;
            text-align: center;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            font-size: 2.2rem;
            font-weight: 600;
        }

        .dashboard {
            max-width: 400px;
            margin: 40px auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
        }

        .dashboard a {
            display: block;
            text-decoration: none;
            background-color: #0096FF;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            margin: 15px 0;
            font-size: 1.1rem;
            transition: background-color 0.3s, transform 0.2s;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .dashboard a:hover {
            background-color: #4fc3f7;
            transform: translateY(-2px);
        }

        .logout-btn {
            background-color: #f06292;
        }

        .logout-btn:hover {
            background-color: #e91e63;
        }

        footer {
            margin-top: 20px;
            text-align: center;
            color: #777;
        }

        footer p {
            font-size: 0.85rem;
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            body {
                padding: 10px;
            }

            .dashboard {
                width: 100%;
            }

            .dashboard a {
                font-size: 1rem;
                padding: 12px;
            }

            header h1 {
                font-size: 1.8rem;
            }
        }

        /* Button press effect */
        .dashboard a:active {
            transform: scale(0.98);
        }
    </style>
</head>
<body>
    <header>
        <h1>Admin Dashboard</h1>
    </header>

    <div class="dashboard">
        <a href="view_users.php">View Students</a>
        <a href="view_groups.php">View Teachers</a>
        <a href="view_applicants.php">View Applicants</a>
        <a href="add_job.php">Add Job Recruitments</a>
        <a href="view_jobs.php">View Jobs</a> <!-- New "View Jobs" button -->
        <a href="admin_logout.php" class="logout-btn">Logout</a>
    </div>

    <footer>
        <p>&copy; 2024 Vote4Teachers. All rights reserved.</p>
    </footer>
</body>
</html>