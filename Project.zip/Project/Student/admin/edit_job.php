<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include '../../TeacherJob/connect.php'; // Connect to the database

// Get job ID from URL
if (isset($_GET['id'])) {
    $job_id = intval($_GET['id']);

    // Fetch job details from the database
    $job_sql = "SELECT * FROM jobs WHERE id = ?";
    $stmt = $conn->prepare($job_sql);
    $stmt->bind_param("i", $job_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $job = $result->fetch_assoc();
    } else {
        header("Location: view_jobs.php?error=Job not found");
        exit();
    }
    $stmt->close();
} else {
    header("Location: view_jobs.php?error=Invalid job ID");
    exit();
}

// Handle form submission to update the job
if (isset($_POST['update'])) {
    $job_title = $_POST['job_title'];
    $closing_date = $_POST['closing_date'];
    $job_description = $_POST['job_description'];

    // Update the job in the database
    $update_sql = "UPDATE jobs SET job_title = ?, closing_date = ?, description = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("sssi", $job_title, $closing_date, $job_description, $job_id);

    if ($stmt->execute()) {
        header("Location: view_jobs.php?message=Job updated successfully");
        exit(); // Make sure to exit after header to prevent further code from running
    } else {
        header("Location: edit_job.php?id=$job_id&error=Error updating job");
        exit();
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Job</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            font-size: 28px;
        }
        label {
            font-weight: bold;
            color: #555;
            display: block;
            margin-bottom: 8px;
        }
        input, textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            color: #555;
            transition: border-color 0.3s;
        }
        input:focus, textarea:focus {
            border-color: #3498db;
            outline: none;
        }
        button {
            width: 100%;
            padding: 14px;
            background-color: #3498db;
            border: none;
            color: white;
            font-size: 18px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #2980b9;
        }
        .error-message {
            color: #e74c3c;
            font-weight: bold;
            text-align: center;
        }
        @media (max-width: 600px) {
            .container {
                width: 90%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Job</h2>
    <?php if (isset($_GET['error'])): ?>
        <p class="error-message"><?php echo htmlspecialchars($_GET['error']); ?></p>
    <?php endif; ?>
    <form action="edit_job.php?id=<?php echo $job_id; ?>" method="POST">
        <label for="job_title">Job Title:</label>
        <input type="text" id="job_title" name="job_title" value="<?php echo htmlspecialchars($job['job_title']); ?>" required>

        <label for="closing_date">Closing Date:</label>
        <input type="date" id="closing_date" name="closing_date" value="<?php echo htmlspecialchars($job['closing_date']); ?>" required>

        <label for="job_description">Job Description:</label>
        <textarea id="job_description" name="job_description" rows="5" required><?php echo htmlspecialchars($job['description']); ?></textarea>

        <button type="submit" name="update">Update Job</button>
    </form>
</div>

</body>
</html>