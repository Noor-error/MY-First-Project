<?php
include 'teacher_jobs_connect.php';  // Connect to the teacher_jobs database

// Fetch applicants from the teacher_jobs database
$sql = "SELECT id, name FROM applications";
$result = $teacher_conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Applicants</title>
    <style>
        body {
            font-family: 'Raleway', sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        header {
            text-align: center;
            background-color: #007BFF; /* Blue header */
            color: white;
            padding: 20px 0;
        }

        section {
            width: 80%;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #007BFF; /* Blue header for table */
            color: white;
        }

        tr:hover {
            background-color: #e7f1ff; /* Light blue on hover */
        }

        footer {
            text-align: center;
            margin-top: 20px;
        }

        footer a {
            text-decoration: none;
            color: #007BFF; /* Blue footer link */
            font-weight: bold;
        }

        footer a:hover {
            text-decoration: underline;
        }
         .container {
            text-align: center;
            margin-bottom: 20px;
         }
         #backbtn {
            padding: 10px 15px;
            background-color: #f44336;
            color: white;
            border-radius: 8px;
            border: none;
            text-decoration: none;
            font-size: 1rem;
            transition: background-color 0.3s;
        }

        #backbtn:hover {
            background-color: #f44336;
        }
         
    </style>
</head>
<body>
    <header>
        <h1>Job Applicants</h1>
    </header>

    <section>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td><a href='view_applicant_details.php?id={$row['id']}' style='color: #007BFF;'>{$row['id']}</a></td>
                            <td><a href='view_applicant_details.php?id={$row['id']}' style='color: #007BFF;'>{$row['name']}</a></td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='2'>No applicants found</td></tr>";
            }
            ?>
        </table>
    </section>

    <footer>
          <div class="container">
         <a href="admin_dashboard.php" id="backbtn">Back to Admin Dashboard</a>
    </div>
      
    </footer>
</body>
</html>

<?php
$teacher_conn->close();
?>