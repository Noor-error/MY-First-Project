<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include '../../TeacherJob/connect.php'; // Connect to the database

// Get job ID from the URL
if (isset($_GET['id'])) {
    $job_id = intval($_GET['id']);

    // Delete the job from the database
    $delete_sql = "DELETE FROM jobs WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $job_id);

    if ($stmt->execute()) {
        // Redirect back to view_jobs.php with success message
        header("Location: view_jobs.php?message=Job deleted successfully");
    } else {
        // Redirect back to view_jobs.php with error message
        header("Location: view_jobs.php?error=Error deleting job");
    }

    $stmt->close();
} else {
    header("Location: view_jobs.php?error=Invalid job ID");
}

$conn->close();
?>