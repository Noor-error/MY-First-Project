<?php
session_start();
include("../api/connect.php");

// Check if the admin is logged in
if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();
}

// Fetch users data
$query = "SELECT id, name, mobile, address FROM users WHERE role = 1";
$users = mysqli_query($connect, $query);

if (!$users) {
    die("Query failed: " . mysqli_error($connect));
}

// Handle delete user action
if (isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];

    // Use prepared statement to prevent SQL injection
    $stmt = mysqli_prepare($connect, "DELETE FROM users WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    $delete_user = mysqli_stmt_execute($stmt);

    if ($delete_user) {
        echo "<script>alert('User Deleted Successfully!'); window.location = 'view_users.php';</script>";
    } else {
        echo "<script>alert('Error Deleting User!'); window.location = 'view_users.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Users</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #e7f3fe;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }

        header {
            background-color: #2196f3;
            color: white;
            text-align: center;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        table {
            width: 100%;
            max-width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin: 0 auto;
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #2196f3;
            color: white;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f1f9ff;
        }

        tr:hover {
            background-color: #e3f2fd;
        }

        form {
            display: inline;
        }

        input[type="submit"] {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #e60000;
        }

        #backbtn {
            padding: 10px 15px;
            background-color: #f44336;
            color: white;
            border-radius: 8px;
            border: none;
            text-decoration: none;
            font-size: 1rem;
            transition: background-color 0.3s;
        }

        #backbtn:hover {
            background-color: #f44336;
        }

        .container {
            text-align: center;
            margin: 20px;
        }

        @media (max-width: 600px) {
            table {
                font-size: 12px;
            }

            th, td {
                padding: 10px;
            }

            #backbtn {
                font-size: 14px;
                width: 100px;
            }

            header {
                padding: 10px 0;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Admin Panel</h1>
    </header>
    
    <div class="container">
        <a href="admin_dashboard.php" id="backbtn">Back</a>
    </div>

    <h2>Users List</h2>

    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Mobile</th>
                <th>Address</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($users)) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['mobile']); ?></td>
                <td><?php echo htmlspecialchars($row['address']); ?></td>
                <td>
                    <form method="post" action="view_users.php">
                        <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                        <input type="submit" name="delete_user" value="Delete" onclick="return confirm('Are you sure you want to delete this user?');">
                    </form>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>