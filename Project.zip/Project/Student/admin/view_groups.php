<?php
session_start();
include("../api/connect.php");

// Check if the admin is logged in
if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();
}

// Generate a new CSRF token if one is not already set
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Generate a 32-byte token
}

// Fetch groups data using prepared statements
$stmt = mysqli_prepare($connect, "SELECT * FROM users WHERE role = ?");
$role = 2;
mysqli_stmt_bind_param($stmt, 'i', $role);
mysqli_stmt_execute($stmt);
$groups = mysqli_stmt_get_result($stmt);

if (!$groups) {
    die("Query failed: " . mysqli_error($connect));
}

// Handle delete group action
if (isset($_POST['delete_group'])) {
    // Check if the CSRF token exists and matches
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Invalid CSRF token!");
    }

    $group_id = $_POST['group_id'];

    // Use prepared statement to prevent SQL injection
    $stmt = mysqli_prepare($connect, "DELETE FROM users WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $group_id);
    $delete_group = mysqli_stmt_execute($stmt);

    if ($delete_group) {
        header("Location: view_groups.php");
        exit();
    } else {
        echo "<script>alert('Error Deleting Group!'); window.location = 'view_groups.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Groups</title>
    <style>
        /* Same CSS as before */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #e7f3fe;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }

        header {
            background-color: #2196f3;
            color: white;
            text-align: center;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        h1 {
            font-size: 1.8rem;
        }

        h2 {
            text-align: center;
            color: #333;
            font-size: 1.5rem;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            max-width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin: 0 auto;
        }

        th, td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #2196f3;
            color: white;
            font-weight: bold;
        }

        td {
            background-color: #f1f9ff;
            color: #333;
        }

        tr:nth-child(even) {
            background-color: #e3f2fd;
        }

        tr:hover {
            background-color: #bbdefb;
        }

        form {
            display: inline-block;
        }

        input[type="submit"] {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #e60000;
        }

        #backbtn {
            padding: 10px 15px;
            background-color: #f44336;
            color: white;
            border-radius: 8px;
            border: none;
            text-decoration: none;
            font-size: 1rem;
            transition: background-color 0.3s;
        }

        #backbtn:hover {
            background-color: #f44336;
        }

        .container {
            text-align: center;
            margin-bottom: 20px;
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            body {
                padding: 10px;
            }

            table, th, td {
                font-size: 0.85rem;
            }

            #backbtn {
                width: 100px;
                padding: 8px;
                font-size: 0.85rem;
            }

            input[type="submit"] {
                font-size: 0.85rem;
                padding: 6px 12px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Admin Panel</h1>
    </header>
    
    <div class="container">
        <a href="view_users.php" id="backbtn">Go to user</a>
    </div>

    <h2>Groups List</h2>

    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Votes</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($groups)) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['address']); ?></td>
                <td><?php echo htmlspecialchars($row['votes']); ?></td>
                <td>
                    <form method="post" action="view_groups.php">
                        <input type="hidden" name="group_id" value="<?php echo $row['id']; ?>">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="submit" name="delete_group" value="Delete" onclick="return confirm('Are you sure you want to delete this group?');">
                    </form>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>