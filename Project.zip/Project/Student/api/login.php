<?php
session_start();
include("connect.php");

$mobile = mysqli_real_escape_string($connect, $_POST['mobile']);
$password = $_POST['password'];
$role = $_POST['role'];

// Use prepared statements to prevent SQL injection
$stmt = mysqli_prepare($connect, "SELECT * FROM users WHERE mobile = ? AND role = ?");
mysqli_stmt_bind_param($stmt, "ss", $mobile, $role);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    $userdata = mysqli_fetch_array($result);

    // Verify the hashed password
    if (password_verify($password, $userdata['password'])) {
        // Fetch groups data (for students to vote on teachers)
        $groups = mysqli_query($connect, "SELECT * FROM users WHERE role = 2");
        $groupsdata = mysqli_fetch_all($groups, MYSQLI_ASSOC);

        $_SESSION['userdata'] = $userdata;
        $_SESSION['groupsdata'] = $groupsdata;

        // Redirect based on role
        if ($role == 1) {
            // Redirect to the Student dashboard
            echo '
            <script>
            window.location = "../routes/dashboard.php";
            </script>
            ';
        } elseif ($role == 2) {
            // Redirect to the TeacherJob section
            echo '
            <script>
            window.location = "../../TeacherJob/index.php";
            </script>
            ';
        }
    } else {
        echo '
        <script>
        alert("Invalid Password! Please try again.");
        window.location = "../index.html";
        </script>
        ';
    }
} else {
    echo '
    <script>
    alert("Invalid Credentials or User Not Found!");
    window.location = "../index.html";
    </script>
    ';
}
