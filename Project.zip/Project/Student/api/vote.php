<?php

session_start();
include('connect.php');

$votes = (int)$_POST['gvotes'];
$total_votes = $votes + 1;
$gid = (int)$_POST['gid'];
$uid = (int)$_SESSION['userdata']['id'];

// Use prepared statements to prevent SQL injection
$update_votes_stmt = mysqli_prepare($connect, "UPDATE users SET votes = ? WHERE id = ?");
mysqli_stmt_bind_param($update_votes_stmt, "ii", $total_votes, $gid);
$update_votes = mysqli_stmt_execute($update_votes_stmt);

$update_user_status_stmt = mysqli_prepare($connect, "UPDATE users SET status = 1 WHERE id = ?");
mysqli_stmt_bind_param($update_user_status_stmt, "i", $uid);
$update_user_status = mysqli_stmt_execute($update_user_status_stmt);

if ($update_votes && $update_user_status) {
    $groups = mysqli_query($connect, "SELECT * FROM users WHERE role = 2");
    $groupsdata = mysqli_fetch_all($groups, MYSQLI_ASSOC);

    $_SESSION['userdata']['status'] = 1;
    $_SESSION['groupsdata'] = $groupsdata;

    echo '
    <script>
    alert("Voting Successful!");
    window.location = "../routes/dashboard.php";
    </script>
    ';
} else {
    echo '
    <script>
    alert("Some error occurred!");
    window.location = "../routes/dashboard.php";
    </script>
    ';
}

?>