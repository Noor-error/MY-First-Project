<?php

include("connect.php");

$name = mysqli_real_escape_string($connect, $_POST['name']);
$mobile = mysqli_real_escape_string($connect, $_POST['mobile']);
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];
$address = mysqli_real_escape_string($connect, $_POST['address']);
$image = $_FILES['photo']['name'];
$tmp_name = $_FILES['photo']['tmp_name'];
$role = $_POST['role'];

if ($password == $cpassword) {

    // Check if the mobile number already exists
    $check_mobile = mysqli_query($connect, "SELECT * FROM users WHERE mobile='$mobile'");
    
    if (mysqli_num_rows($check_mobile) > 0) {
        echo '
        <script>
        alert("This mobile number is already registered!");
        window.location = "../index.html";
        </script>
        ';
        exit; // Stop execution if the mobile number exists
    }

    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    if (move_uploaded_file($tmp_name, "../uploads/$image")) {

        $insert = mysqli_query($connect, "INSERT INTO users (name, mobile, address, password, photo, role, status, votes) 
                    VALUES ('$name', '$mobile', '$address', '$hashed_password', '$image', '$role', 0, 0)");

        if ($insert) {
            echo '
            <script>
            alert("Registration Successful!");
            window.location = "../index.html";
            </script>
            ';
        } else {
            echo '
            <script>
            alert("Some Error Occurred! Please try again.");
            window.location = "../index.html";
            </script>
            ';
        }
    } else {
        echo '
        <script>
        alert("Failed to upload the image! Please try again.");
        window.location = "../index.html";
        </script>
        ';
    }
} else {
    echo '
    <script>
    alert("Password and Confirm Password do not match!");
    window.location = "../index.html";
    </script>
    ';
}

?>
