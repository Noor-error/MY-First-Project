<?php
include 'connect.php';

// Fetch all jobs where the closing date is not in the past
$sql = "SELECT jobs.id, jobs.job_title, jobs.description, jobs.qualifications, jobs.closing_date, schools.name AS school_name 
        FROM jobs 
        JOIN schools ON jobs.school_id = schools.id
        WHERE jobs.closing_date >= CURDATE()";  // Only show jobs that are still open

$result = $conn->query($sql);
$jobs = array();

if ($result->num_rows > 0) {
    // Fetch each job and add to the jobs array
    while($row = $result->fetch_assoc()) {
        $jobs[] = $row;
    }
}

// Return the result as a JSON response
header('Content-Type: application/json');
echo json_encode($jobs);
?>