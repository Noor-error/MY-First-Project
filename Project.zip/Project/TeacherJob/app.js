document.addEventListener('DOMContentLoaded', () => {
    fetchJobs();
});

function fetchJobs() {
    fetch('get_jobs.php')  // Fetching jobs from the get_jobs.php file
        .then(response => response.json())  // Parsing the response as JSON
        .then(data => {
            let jobListings = document.getElementById('job-listings');
            jobListings.innerHTML = ''; // Clear any previous job listings

            // Check if there are jobs
            if (data.length > 0) {
                // Loop through each job and create the HTML structure
                data.forEach(job => {
                    let jobCard = `
                        <div class="job-card">
                            <h3 class="job-title">${job.job_title}</h3>
                            <p class="job-description">${job.description}</p>
                            <div class="job-info">
                                <span>School: ${job.school_name}</span>
                                <span>Closing Date: ${job.closing_date}</span>
                            </div>
                            <a href="apply.php?job_id=${job.id}" class="apply-btn">Apply Now</a>
                        </div>
                    `;
                    jobListings.innerHTML += jobCard;
                });
            } else {
                // If no jobs are available
                jobListings.innerHTML = '<p>No jobs available at the moment.</p>';
            }
        })
        .catch(error => {
            console.error('Error fetching jobs:', error);
        });
}