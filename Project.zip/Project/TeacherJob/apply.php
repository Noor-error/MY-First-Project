<?php
include 'connect.php';

$job_id = $_GET['job_id'];
$job_sql = "SELECT job_title FROM jobs WHERE id = $job_id";
$job_result = $conn->query($job_sql);
$job = $job_result->fetch_assoc();

// Check for status message in the URL
$status = isset($_GET['status']) ? $_GET['status'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Job</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f0f0f0;
            color: #333;
        }

        header {
            text-align: center;
            background-color: #007BFF; /* Blue color */
            color: white;
            padding: 20px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            font-size: 28px;
            margin-bottom: 5px;
        }

        section {
            width: 90%;
            max-width: 600px;
            margin: 40px auto;
            background-color: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-bottom: 20px;
            font-size: 22px;
            text-align: center;
        }

        p {
            font-size: 16px;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-size: 16px;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="file"] {
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
        }

        button {
            background-color: #007BFF; /* Blue color */
            color: white;
            padding: 12px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3; /* Darker blue for hover */
        }

        .success, .error {
            font-size: 18px;
            text-align: center;
            margin-bottom: 20px;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }

        @media (max-width: 768px) {
            section {
                width: 90%;
            }

            header h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Apply for <?= $job['job_title'] ?></h1>
    </header>

    <section>
        <?php if ($status === 'success'): ?>
            <p class="success">Application submitted successfully!</p>
        <?php elseif ($status === 'error'): ?>
            <p class="error">Error: Unable to submit the application. Please try again.</p>
        <?php elseif ($status === 'upload_error'): ?>
            <p class="error">Error: Failed to upload the resume. Please try again.</p>
        <?php endif; ?>

        <form action="submit_application.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="job_id" value="<?= $job_id ?>">

            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="phone">Phone:</label>
            <input type="tel" id="phone" name="phone" required>

            <label for="resume">Upload Resume:</label>
            <input type="file" id="resume" name="resume" accept=".pdf,.docx" required>

            <button type="submit">Submit Application</button>
        </form>
    </section>
</body>
</html>