<?php
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $job_id = $_POST['job_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    
    // Handle file upload
    $resume = $_FILES['resume']['name'];
    $resume_tmp = $_FILES['resume']['tmp_name'];
    $resume_folder = 'resumes/' . basename($resume);

    // Ensure only specific file types are allowed (e.g., .pdf, .docx)
    $allowed_extensions = ['pdf', 'docx'];
    $file_extension = pathinfo($resume, PATHINFO_EXTENSION);

    if (!in_array($file_extension, $allowed_extensions)) {
        header("Location: apply.php?job_id=$job_id&status=upload_error");
        exit();
    }

    // Move uploaded resume to the resumes folder
    if (move_uploaded_file($resume_tmp, $resume_folder)) {
        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO applications (job_id, name, email, phone, resume) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $job_id, $name, $email, $phone, $resume);

        if ($stmt->execute()) {
            // Redirect back to apply.php with a success message
            header("Location: apply.php?job_id=$job_id&status=success");
            exit();
        } else {
            // Redirect back to apply.php with an error message
            header("Location: apply.php?job_id=$job_id&status=error");
            exit();
        }
    } else {
        // Redirect back to apply.php with an upload error message
        header("Location: apply.php?job_id=$job_id&status=upload_error");
        exit();
    }
}
?>