<?php
session_start();

// Check if user data is available in the session
if (!isset($_SESSION['userdata'])) {
    // If no user is logged in, redirect to the login page
    echo '
    <script>
    alert("Please log in first.");
    window.location = "../index.html";
    </script>
    ';
    exit();
}

// Fetch the user's name from session data
$user_name = $_SESSION['userdata']['name']; // Assuming 'name' is the column for the teacher's name
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teachers Jobs</title>
    <style>
    
    .view-profile-btn {
        position: absolute;
        right: 20px;
        top: 20px;
        background-color: #008000;
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 8px;
        font-size: 14px;
        cursor: pointer;
    }

    /* Modal for displaying profile */
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
    }

    .modal-content {
        background-color: white;
        padding: 20px;
        border-radius: 8px;
        width: 300px;
        text-align: center;
    }

    .close-btn {
        margin-top: 10px;
        background-color: red;
        color: white;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
    }

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Poppins', sans-serif;
    background-color: #f1f4f8;
    color: #333;
    line-height: 1.6;
    padding: 20px;
}

header {
    background-color: #0066CC; /* Darker blue for a more professional look */
    color: white;
    padding: 20px;
    text-align: center;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    border-radius: 12px;
}

header h1 {
    font-size: 36px;
    margin-bottom: 10px;
    letter-spacing: 1.5px;
}

#job-listings {
    width: 90%;
    max-width: 1200px;
    margin: 40px auto;
    padding: 30px;
    background-color: white;
    border-radius: 12px;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
}

.job-card {
    padding: 20px 0;
    margin-bottom: 20px; /* Space between jobs */
    border-bottom: 1px solid #ddd; /* Separator line */
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
}

.job-card:hover {
    background-color: #f9f9f9;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
}

.job-title {
    font-size: 26px; /* Slightly larger */
    color: #0066CC;
    font-weight: bold;
    margin-bottom: 10px;
}

.job-description {
    font-size: 16px;
    margin-bottom: 10px;
    line-height: 1.6;
}

.job-info {
    font-size: 14px;
    color: #666;
}

.job-info span {
    display: inline-block;
    margin-right: 20px;
}

.apply-btn {
    display: inline-block;
    margin-top: 15px;
    padding: 12px 24px; /* Larger button */
    background-color: #008000;
    color: white;
    text-decoration: none;
    border-radius: 8px;
    transition: background-color 0.3s ease, transform 0.2s ease;
    font-size: 16px;
    font-weight: bold;
}

.apply-btn:hover {
    background-color: #008000;
    transform: scale(1.05);
}

footer {
    text-align: center;
    padding: 20px;
    background-color: #333;
    color: white;
    margin-top: 40px;
    font-size: 14px;
    border-radius: 10px;
}

/* Responsive Design */
@media (max-width: 768px) {
    header h1 {
        font-size: 28px;
    }

    .job-title {
        font-size: 22px;
    }

    .job-description {
        font-size: 14px;
    }

    .job-info {
        font-size: 12px;
    }
}
      
      
    </style>
</head>
<body>
    <header>
        <h1>Welcome,<?php echo htmlspecialchars($user_name); ?></h1>
    </header>
    <section id="job-listings">
        <!-- Job listings will be loaded here using JavaScript -->
    </section>
    <footer>
        <p>&copy; 2024 Teacher Jobs</p>
    </footer>
    <script src="app.js"></script>
</body>
</html>